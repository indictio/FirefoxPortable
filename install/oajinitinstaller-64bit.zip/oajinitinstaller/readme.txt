How to install
 - double click setup.bat